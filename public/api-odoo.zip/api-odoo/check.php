<?php
require_once 'core/db.php';
require_once 'core/functions.php';
require_once('ripcord/ripcord.php');
require_once 'core/odoo_functions.php';

$uid =odoo_authenticate($odoo_url_auth,$odoo_db, $odoo_username, $odoo_password);
print("<p>Your current user id is '${uid}'</p>");
$models = odoo_logging_in($odoo_url_exec);

/* $rs=$models->execute_kw($odoo_db, $uid, $odoo_password,
    'account.move', 'fields_get',
    array(), array('attributes' => array('string', 'help', 'type','required')));

var_dump($rs);exit(); */

//$results_odoo_search_invoice=odoo_search_read_invoice($models,$odoo_db, $uid, $odoo_password,$invoice_number);
$rs=$models->execute_kw($odoo_db, $uid, $odoo_password,
        'account.move', 'search_read',
        array(array(array('id', '=', 207))),
        array());
        var_dump($rs);exit();