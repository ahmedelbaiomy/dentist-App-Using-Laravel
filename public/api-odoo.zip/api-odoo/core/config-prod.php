<?php
//dentinizer db
$host='127.0.0.1';
$dbname='offersha_medicals_new';
$user='offersha_medicals_new';
$password='9?sTD!2%kf5}';
//odoo
$odoo_url = 'http://139.59.147.49:8069';
$odoo_url_auth = $odoo_url . '/xmlrpc/2/common';
$odoo_url_exec = $odoo_url . '/xmlrpc/2/object';
$odoo_db = 'odoodb1';
$odoo_username = 'reviewcost@gmail.com';
$odoo_password = 'kF3Y7j97CNhm';


 